﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafio_1___ficha_1
{
    public class Quadrado
    {
        double lado;

        // Cria Construtor com dado padrão
        public Quadrado() 
        {
            lado = 1.0;

        }


        // Cria Construtor com dado definido pelo utlizador
        public Quadrado(double lado)
        {
            this.lado = lado;
        }



        // Método para alterar o lado
        public void alterarlado(double v)
        {
            lado = v;
        }



        // Método output
        public double Perimetro()
        {
            return lado + lado + lado + lado;
        }

        public double Area()
        {
            return lado * lado;
        }

        public double Vertical()
        {
            return Math.Sqrt(2) * lado;
        }
    }
}


