﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace desafio_1___ficha_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Quadrado quadrado = new Quadrado();
            Quadrado quadrado2 = new Quadrado(6.0);
            quadrado2.alterarlado(10);

            Console.WriteLine(quadrado2.Perimetro());
            Console.WriteLine(quadrado2.Area());
            Console.WriteLine(quadrado2.Vertical());
        }
    }
}
